//
//  AppDelegate.h
//  ShareDemo
//
//  Created by 典盟金融 on 15-6-25.
//  Copyright (c) 2015年 jacky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SinaCallBack.h"
#import "ViewController.h"
#import "ShareSdk.h"

#import "Header.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) SinaCallBack *SinaWbCb;

@end

