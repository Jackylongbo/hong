//
//  SinaCallBack.m
//  ShareDemo
//
//  Created by 典盟金融 on 15-6-25.
//  Copyright (c) 2015年 jacky. All rights reserved.
//

#import "SinaCallBack.h"

@implementation SinaCallBack

@end
