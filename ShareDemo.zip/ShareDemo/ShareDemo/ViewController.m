//
//  ViewController.m
//  ShareDemo
//
//  Created by 典盟金融 on 15-6-25.
//  Copyright (c) 2015年 jacky. All rights reserved.
//

#import "ViewController.h"
//#import "SinaCallBack.h"
#import "FreeGeekSheet.h"
#import "Header.h"
#import "ShareSdk.h"

@interface ViewController ()<FreeGeekDelegate>
{
    BOOL showRedDot;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    showRedDot=NO;
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    if (_shareSDK==nil) {
        _shareSDK=[[ShareSdk alloc]init];
    }
    _SinaCB=[[SinaCallBack alloc] init];
    [ShareSdk connectSinaWithAppKey:SinaWBAppKey];
    
    defaults=[NSUserDefaults standardUserDefaults];
    //
    NSDictionary *shareContentDict=[[ShareSdk GetShareContent] objectForKey:@"object"];
    ShareTitle = [shareContentDict objectForKey:@"shareTitle"];
    ShareURL=[shareContentDict objectForKey:@"shareLink"];
    ShareMessage=[shareContentDict objectForKey:@"shareDescription"];
    ShareImageURL=[shareContentDict objectForKey:@"sharePicUrl"];
    ShareVideoURL=[shareContentDict objectForKey:@""];
    ShareImage=[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:ShareImageURL]]];
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    titleArray = [[NSArray alloc]init];
    imageArray = [[NSArray alloc]init];
    pointArray =[[NSArray alloc]init];
    titleArray =@[@"新浪微博",@""];
    imageArray =@[@"sina",@""];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ShareBtnAction:(id)sender {
    
    FreeGeekSheet * freegeeksheet=[[FreeGeekSheet alloc]initWithTitle:@"分享推荐" Delegate:self titleArray:titleArray imageArray:imageArray PointArray:pointArray ShowRedDot:showRedDot ActivityName:nil Middle:NO];
    [freegeeksheet ShowInView:self.view];
}
-(void)ShareButtonAction:(NSInteger *)buttonIndex
{
    [self SinaShare];

}
-(void)SinaShare
{
    [ShareSdk SinaWbShareMessage:ShareMessage Image:ShareImage Url:ShareURL];

}
@end
