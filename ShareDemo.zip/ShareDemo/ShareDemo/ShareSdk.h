//
//  YouTuiSDK.h
//  YouTuiSDK
//
//  Created by FreeGeek on 14-10-19.
//  Copyright (c) 2014年 FreeGeek. by Gz.bidaround----Version: 1.1
//

#import <Foundation/Foundation.h>
//#import "WeiboApi.h"
#import "WeiboSDK.h"
//#import "WXApi.h"
//#import "RennShareComponent.h"
//#import <MessageUI/MessageUI.h>
//#import <TencentOpenAPI/QQApiInterface.h>
//#import <TencentOpenAPI/TencentOAuth.h>
//#import <TencentOpenAPI/QQApiInterfaceObject.h>
//#import <RennSDK/RennSDK.h>
@interface YouTuiSDK : NSObject
#pragma mark ----------新浪微博----------
/**
 *  新浪微博初始化
 *
 *  @param AppKey 新浪微博开放平台初始化
 *
 *  @return 注册成功返回YES,失败返回NO
 */
+(BOOL)connectSinaWithAppKey:(NSString *)AppKey;
/**
 *  新浪微博设置调试模式
 *
 *  @param enabled 开启或者关闭调试模式
 */
+(void)enableDebugMode:(BOOL)enabled;
/**
 *  新浪微博授权登陆
 *
 *  @param URI 授权回调URI
 */
-(void)SinaWbLogin:(NSString *)URI;
/**
 *  新浪微博登出授权接口
 *
 *  @param token    第三方应用之前申请的token
 *  @param delegate 用于接受微博SDK对于发起的接口请求的响应
 *  @param Tag      用户自定义
 */
-(void)SinaWbLogoutWithToken:(NSString *)token
                    Delegate:(id)delegate
                     WithTag:(NSString *)Tag;

/**
 *  根据用户id获取用户信息
 *
 *  @param Appkey 新浪微博开放平台申请的Appkey
 *  @param Uid    用户ID
 *
 *  @return 用户信息
 */
+(NSDictionary *)SinaGetUserInfoWithAppkey:(NSString *)Appkey Uid:(NSString *)Uid;
/**
 *  新浪微博客户端回调
 *
 *  @param url      启动App的Url
 *  @param delegate self 用于接受微博触发的消息
 *
 *  @return 回调成功返回YES,失败返回NO
 */
+(BOOL)SinaWbhandleOpenURL:(NSURL *)url
                  delegate:(id)delegate;
/**
 *  新浪微博图文分享
 *
 *  @param message 文本内容
 *  @param Image   图片
 *  @param url     网页的URL
 */
+(void)SinaWbShareMessage:(NSString *)message
                    Image:(UIImage *)Image
                      Url:(NSString *)url;
/**
 *  新浪微博多媒体分享
 *
 *  @param message      文本内容
 *  @param ID           对象唯一ID
 *  @param title        多媒体网页标题
 *  @param description  多媒体内容描述
 *  @param thumbnaiData 多媒体内容缩略图
 *  @param url          网页的Url
 */
+(void)SinaWbShareMessage:(NSString *)message
                       ID:(NSString *)ID
                    Title:(NSString *)title
              Description:(NSString *)description
             ThumbnaiData:(NSData *)thumbnaiData
                      Url:(NSString *)url;

/**
 *  检查用户是否安装了微博客户端程序
 *
 *  @return 已安装返回YES,未安装返回NO
 */
+(BOOL)SinaIsAppInstalled;

#pragma mark ----------友推积分系统----------
/**
 *  友推平台初始化
 *
 *  @param AppId      平台注册的AppId
 *  @param inviteCode 邀请码
 *  @param appUserId  用户ID
 *  @param imei       唯一标识符
 */
+(void)connectYouTuiSDKWithAppId:(NSString *)AppId
                      inviteCode:(NSString *)inviteCode
                       appUserId:(NSString *)appUserId;

/**
 *  分享获得积分
 *
 *  @param channelid 频道ID
 *  @param Url       分享的URL
 *  @param point     积分数
 */
+(NSString *)SharePointisShare:(BOOL)isShare;
/**
 *  获取社交平台可以获得的积分
 */
+(NSDictionary *)GetPointRule;
/**
 *  获取唯一设备码
 *
 *  @return 唯一设备码
 */
+(NSString *)GetImei;
/**
 *  积分商城URLRequest
 *
 *  @return URLRequest
 */
+(NSURLRequest *)getPointStoreRequest;
/**
 *  获取友推后台设置的分享内容
 *
 *  @return 分享内容字典
 */
+(NSDictionary *)GetShareContent;

/**
 *  赠送积分
 *
 *  @param Point     赠送的积分数
 *  @param appUserId 到账用户Id
 */
-(NSString *)GetPoint:(NSString *)Point
            appUserId:(NSString *)appUserId;

/**
 *  获得签到积分
 */
-(NSString *)GetloginPoint;

/**
 *  开发者自己添加积分项
 *
 *  @param PointName 用户自定义的积分项目,例如"发帖子","分享"等,具体获得分数需要在友推后台设置
 */
-(NSString *)CustomPoint:(NSString *)PointName;
/**
 *  获取用户积分数
 *
 *  @param AppUserId 用户Id
 */
-(NSString *)addUserPointAppUserId:(NSString *)AppUserId;

/**
 *  扣除用户积分
 *
 *  @param AppUserId   用户Id
 *  @param reducePoint 减少的积分数
 *  @param reason      扣除积分的原因
 */
-(NSString *)reduceUserPointAppUserId:(NSString *)AppUserId
                          reducePoint:(NSString *)reducePoint
                               reason:(NSString *)reason;

/**
 *  用户积分明细
 *
 *  @param AppUserId 用户Id
 */
-(NSString *)checkUserPointAppUserId:(NSString *)AppUserId;

/**
 *  关闭应用时发送相关信息
 */
-(NSString *)CloseApp;
@end


#pragma mark ----------新浪微博代理方法----------
@protocol SinaWbDelegate<NSObject,WeiboSDKDelegate,WBHttpRequestDelegate>
@optional
/**
 *  收到新浪微博客户端程序的请求
 *
 *  @param request 具体的请求对象
 */
-(void)didReceiveWeiboRequest:(WBBaseRequest *)request;
/**
 *  收到新浪微博客户端的相应
 *
 *  @param response 具体的相应对象
 */
-(void)didReceiveWeiboResponse:(WBBaseResponse *)response;
@end

@end

