//
//  ViewController.h
//  ShareDemo
//
//  Created by 典盟金融 on 15-6-25.
//  Copyright (c) 2015年 jacky. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShareSdk.h"
#import "SinaCallBack.h"

@interface ViewController : UIViewController
{
    NSArray *titleArray;
    NSArray *imageArray;
    NSArray *pointArray;
    NSUserDefaults *defaults;
    
    NSString * ShareMessage;
    NSString * ShareURL;
    NSString * ShareVideoURL;
    NSString * ShareImageURL;
    NSString * ShareTitle;
    UIImage * ShareImage;
    
}
@property (strong , nonatomic) SinaCallBack *SinaCB;
@property (strong  , nonatomic)ShareSdk *shareSDK;


- (IBAction)ShareBtnAction:(id)sender;
@end

