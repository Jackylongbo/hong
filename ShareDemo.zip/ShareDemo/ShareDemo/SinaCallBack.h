//
//  SinaCallBack.h
//  ShareDemo
//
//  Created by 典盟金融 on 15-6-25.
//  Copyright (c) 2015年 jacky. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SinaCallBack : NSObject

@end
